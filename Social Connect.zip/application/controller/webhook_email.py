https://catalog.s.download.windowsupdate.com/d/msdownload/update/software/updt/2022/10/windows11.0-kb5019509-x64_19d517d386a7938c7840ac581e3b731e457d7618.msu

https://mirror-leech-kingdom.site/0:/1.%20Root/Recorded%20Live.zip