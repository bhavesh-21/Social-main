export default {
  template: '<div> This is home </div>',
}
